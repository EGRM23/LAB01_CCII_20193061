#include <iostream>
using namespace std;

//EDUARDO GERMAN RUIZ MAMANI
//CURSO: CIENCIAS DE LA COMPUTACION II LAB C
//CUI: 20193061

int main(int argc, char *argv[]) {
	int A, B;
	cout<<"A = ";
	cin>>A;
	cout<<"B = ";
	cin>>B;
	cout<<"AXB = "<<A*B;
	return 0;
}


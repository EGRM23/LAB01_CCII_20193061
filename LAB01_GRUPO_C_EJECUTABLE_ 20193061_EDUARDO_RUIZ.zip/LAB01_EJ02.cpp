#include <iostream>
using namespace std;

//EDUARDO GERMAN RUIZ MAMANI
//CURSO: CIENCIAS DE LA COMPUTACION II LAB C
//CUI: 20193061

int main(int argc, char *argv[]) {
	string n, ap, am, correo;
	cout<<"Nombre: ";
	cin>>n;
	n[0]+=32;
	cout<<"Apellido paterno: ";
	cin>>ap;
	ap[0]+=32;
	cout<<"Apellido materno: ";
	cin>>am;
	am[0]+=32;
	correo=n[0]+ap+am[0]+"@unsa.edu.pe";
	cout<<"CORREO INSTITUCIONAL: "<<correo;
	return 0;
}

